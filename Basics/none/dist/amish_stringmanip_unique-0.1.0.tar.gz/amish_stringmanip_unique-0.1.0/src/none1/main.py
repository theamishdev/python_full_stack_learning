""" from packages import power,simple_math
 """
from test import rem,remo,doc_help
""" b=power.power_in(3,2)
c=simple_math.mul(2,6)
print(b,c)
print(help(power.power_in))  """
print(rem("<>Hii/Bye😎😎</>"))
print(remo("Hii","i"))
print(doc_help())
